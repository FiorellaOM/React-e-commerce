import logo from "../../assets/svg/cart.svg";

const CartWidget = () => {
  return (
    <div>
      <img
        src={logo}
        alt="Shopping Cart"
        style={{ width: "20px", height: "100" }}
      />
    </div>
  );
};
export default CartWidget;
